2015 CapForge V2 — validation repair

This fixes the validation error shown for players[331].surname and removes future draft/signed dates from 2015 active/free-agent players. It also shifts the original future draft classes 2027–2030 to 2016–2019.

IMPORTANT: This does NOT meet the requested 30 verified real players per team. The underlying 2015 beta contains only 436 historically named players, around 14 per team. The remainder are fictional; do not mistake them for authentic 2015 rosters. Historical roster data needs to be integrated to meet 960 verified players.

2015 season is not verified in CapForge. Other validators may surface additional problems. Staff and teams unchanged from beta.

Changes: {'signed_or_free_agent_draft_year': 2560, 'contract_year': 901, 'empty_surname': 1, 'draft_pool_year': 1920}
